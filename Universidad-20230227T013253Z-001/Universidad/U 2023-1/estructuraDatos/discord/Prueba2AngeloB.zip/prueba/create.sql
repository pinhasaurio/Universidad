CREATE TABLE Asignatura (
	codigo_asig text PRIMARY KEY,
	nombre_asig text
);
CREATE TABLE Periodo(
	periodo text PRIMARY KEY
);
CREATE TABLE Profesor(
	rut_profesor text primary key,
	nombre_profesor text
);
CREATE TABLE Estudiante(
	rut_estudiante text primary key,
	nombre_estudiante text,
	apellidos_estudiante text
);



CREATE TABLE Periodo_NRC_asig(
	periodo text NOT NULL,
	asignatura text NOT NULL,
	nrc text NOT NULL,
	PRIMARY KEY (periodo, asignatura, nrc),
	FOREIGN KEY (asignatura) REFERENCES Asignatura (codigo_asig),
	FOREIGN KEY (periodo) REFERENCES Periodo (periodo)
);
CREATE TABLE Paralelo (
	paralelo text primary key
);

CREATE TABLE Paralelos_Asignatura (
	asignatura text NOT NULL,
	paralelo text NOT NULL,
	PRIMARY KEY (asignatura, paralelo),
	FOREIGN KEY (asignatura) REFERENCES Asignatura (codigo_asig),
	FOREIGN KEY (paralelo) REFERENCES Paralelo (paralelo)
);


CREATE TABLE Rendimiento(
	estudiante text NOT NULL,
	codigo_asig text NOT NULL,
	periodo text NOT NULL,
	paralelo text NOT NULL,
	PRIMARY KEY (estudiante , codigo_asig, periodo, paralelo),
	nota integer not null,
	FOREIGN KEY (estudiante) REFERENCES Estudiante(rut_estudiante),
	FOREIGN KEY (codigo_asig) REFERENCES Asignatura (codigo_asig),
	FOREIGN KEY (periodo) REFERENCES Periodo (periodo),
	FOREIGN KEY (paralelo) REFERENCES Paralelo (paralelo)
);
CREATE TABLE Curso(
	profesor text NOT NULL,
	codigo_asig text NOT NULL,
	periodo text NOT NULL,
	paralelo text NOT NULL,
	PRIMARY KEY (profesor , codigo_asig, periodo, paralelo),
	FOREIGN KEY (profesor) REFERENCES Profesor (rut_profesor),
	FOREIGN KEY (codigo_asig) REFERENCES Asignatura (codigo_asig),
	FOREIGN KEY (periodo) REFERENCES Periodo (periodo),
	FOREIGN KEY (paralelo) REFERENCES Paralelo (paralelo)
);