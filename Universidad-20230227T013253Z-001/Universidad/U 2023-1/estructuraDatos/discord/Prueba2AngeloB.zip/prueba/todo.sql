/*5a) Construya un trigger de forma que cada vez que se ingresa o edita un estudiante, su RUT se guarde sin
puntos ni guiones y convertido en mayusculas (para asegurar que los terminados en K se guardan todos ´
de la misma manera)*/
CREATE OR REPLACE FUNCTION nuevo_rut()
	RETURNS TRIGGER
	LANGUAGE PLPGSQL
	AS $$
	DECLARE
		RUT text;
	BEGIN
		RUT  = new.rut_estudiante;
		select replace(RUT,'-','') INTO RUT;
		select replace(RUT,'.','') INTO RUT;
		select upper(RUT) into RUT;
		new.rut_estudiante = RUT;
		RETURN NEW;
	END;
	$$;




CREATE TRIGGER Cambiar_rut
	BEFORE INSERT OR UPDATE
	ON Estudiante
	FOR EACH ROW
	EXECUTE PROCEDURE nuevo_rut();



-----------------------------------------------------------------------------------------------------------------------------------------------------
--5b) Realice lo mismo para la tabla de profesores
CREATE OR REPLACE FUNCTION nuevo_rutP()
	RETURNS TRIGGER
	LANGUAGE PLPGSQL
	AS $$
	DECLARE
		RUT text;
	BEGIN
		RUT  = new.rut_profesor;
		select replace(RUT,'-','') INTO RUT;
		select replace(RUT,'.','') INTO RUT;
		select upper(RUT) into RUT;
		new.rut_profesor = RUT;
		RETURN NEW;
	END;
	$$;
CREATE TRIGGER Cambiar_rutP
	BEFORE INSERT OR UPDATE
	ON Profesor
	FOR EACH ROW
	EXECUTE PROCEDURE nuevo_rut();
	
--------------------------------------------------------------------------------------------------------------------------
/*5c) Construya un trigger sobre la tabla donde se almacena el codigo de las asignaturas, para asegurar de ´
que la tabla solo contiene codigos de la forma ´ XXXX-00000, o sea, 4 letras, un guion y 5 n ´ umeros.*/
--FUNCIÓN CREADA APARTE PARA RESOLVER EL EJERCICIO, VERIFICA SI ES NÚMERO
CREATE OR REPLACE FUNCTION num(text) RETURNS BOOLEAN AS $$
DECLARE
	x NUMERIC;
BEGIN
    x = $1::NUMERIC;
    RETURN TRUE;
EXCEPTION WHEN others THEN
    RETURN FALSE;
END;
$$
LANGUAGE plpgsql;
---------------------------------
CREATE OR REPLACE FUNCTION cambiar_cod()
	RETURNS TRIGGER
	LANGUAGE PLPGSQL
	AS $function$
	DECLARE
		codigo text;
		primeros_d text;
		segundos_d text;
		cant1 integer;
		cant2 integer;
	BEGIN
		codigo = new.codigo_asig;
		select into primeros_d split_part(codigo,'-',1); --supuestas  4 letras
		select into segundos_d split_part(codigo,'-',2); --supuestas  5 num
		if (segundos_d = '') THEN RETURN OLD; END IF; --si la segunda parte es nula es decir no hubo guión, no hay cambio
		--ve longitud
		cant1 := char_length(primeros_d);
		if (cant1 != 4 or cant2 != 5) THEN return old; end if; --si no corresponden al tamaño no hay cambio
		cant2 := char_length(segundos_d);
		
		if(num(primeros_d)) THEN RETURN OLD; END IF; --verifica si son letras o no, si no lo son pasa al return old
		
		if(!num(segundos_d)) THEN RETURN OLD; END IF;--verifica que sean números la segunda parte
		RETURN NEW;
	END;
	$function$;
-----------
CREATE TRIGGER Cambiar_cod_asig
	BEFORE INSERT OR UPDATE
	ON asignatura
	FOR EACH ROW
	EXECUTE PROCEDURE cambiar_cod();
--------------------------------------------------------------------------------------------------------------------------------------------------
/*5d) Construya una tabla llamada promedio_asignatura, con columnas codigo_asignatura, periodo,
promedio que contenga el promedio de notas de una asignatura en un semestre. Esta tabla se debe
mantener actualizada a traves de un trigger que detecte cada vez que se inserta, modifica o borra una ´
nota de un estudiante en un curso.*/
CREATE TABLE promedio_asignatura(
	codigo_asignatura text,
	periodo text,
	promedio integer,
	PRIMARY KEY(codigo_asignatura, periodo),
	FOREIGN KEY (codigo_asignatura) REFERENCES Asignatura(codigo_asig),
	FOREIGN KEY (periodo) REFERENCES Periodo(periodo)
);

CREATE OR REPLACE FUNCTION Retornar_prom()
	RETURNS TRIGGER
	LANGUAGE PLPGSQL
	AS $function$
	DECLARE
		codigo_asi text;
		perio text;
		nota integer;
		sum_nota integer;
		cant_personas integer;
		r_promedio integer;
		estudiantes record;
		prueba text;
	BEGIN
		codigo_asi := new.codigo_asig;
		perio := new.periodo;
		r_promedio := 0;
		sum_nota := 0;
		cant_personas := 0;
		FOR estudiantes IN
		(SELECT * FROM Rendimiento where codigo_asig = codigo_asi and periodo = perio) --la combinación entre estudiante, codigo asig y periodo es primary key
		LOOP
			nota = estudiantes.nota; --nota de un estudiante en esa asignatura
			if (nota != -1) THEN sum_nota := sum_nota + nota; cant_personas:= cant_personas+1; END IF;
		END LOOP;
		if(cant_personas = 0) THEN r_promedio := 0; ELSE r_promedio := sum_nota/cant_personas; END IF;
		
		SELECT codigo_asignatura into prueba FROM promedio_asignatura WHERE codigo_asignatura = codigo_asi AND periodo = perio;
		IF (prueba is null) THEN
		INSERT INTO promedio_asignatura values (codigo_asi, perio, r_promedio);
		return NEW;
		END IF;
		update promedio_asignatura set promedio = r_promedio WHERE codigo_asignatura = codigo_asi AND periodo = perio;
		return NEW;
	END;
	$function$;
	
CREATE TRIGGER VerProm
	AFTER INSERT OR UPDATE OR DELETE
	ON Rendimiento
	FOR EACH ROW
	EXECUTE PROCEDURE Retornar_prom();
-----------------------------------------------------------------------------------------------------------------------------------------------------
/*5e) Construya una tabla llamada cursos_profesor, con columnas periodo, 
rut_profesor, cantidad,
que contenga la cantidad de cursos que un profesor dicta en un semestre.
Esta tabla se debe mantener
actualizada a traves de un trigger que se gatille apropiadamente 
para mantener la informacion en la
tabla*/
CREATE TABLE cursos_profesor(
	periodo text,
	rut_profesor text,
	cantidad integer,
	PRIMARY KEY (periodo, rut_profesor),
	FOREIGN KEY (periodo) REFERENCES Periodo (periodo),
	FOREIGN KEY (rut_profesor) REFERENCES Profesor (rut_profesor)
);

CREATE OR REPLACE FUNCTION profesor_cant_curso()
	RETURNS TRIGGER
	LANGUAGE PLPGSQL
	AS $function$
	DECLARE
		prof text;
		perio text;
		can integer;
		prueba text;
	BEGIN
		prof := NEW.profesor;
		perio := NEW.periodo;
		
		SELECT count(*) into can FROM Curso WHERE profesor = prof and periodo = perio;
		
		SELECT rut_profesor into prueba FROM cursos_profesor WHERE periodo = perio and rut_profesor = prof;
		IF(prueba is null) 
		THEN insert into cursos_profesor values (perio,prof,can);
		RETURN NEW;
		END IF;
		UPDATE cursos_profesor set cantidad = can WHERE periodo = perio and rut_profesor = prof;
		RETURN NEW;
	END;
	$function$;


CREATE TRIGGER Actualizar_cursos_profesor
	AFTER INSERT OR UPDATE OR DELETE
	ON Curso
	FOR EACH ROW
	EXECUTE PROCEDURE profesor_cant_curso();
-----------------------------------------------------------------------------------------------------------------------------------------------------
--5f) Genere una consulta que indique los NRC que se dictaron el periodo 202020, pero no el 202110
select * from
(select distinct nrc from Periodo_NRC_asig WHERE periodo = '202020')as s where s. nrc not in
(select distinct nrc from Periodo_NRC_asig WHERE periodo = '202110')	

-----------------------------------------------------------------------------------------------------------------------------------------------------

--5g) Genere una consulta que indique las asignaturas que se dictaron el periodo 202020, pero no el 202110.
select * from
(select asi.codigo_asig, asi.nombre_asig from asignatura asi INNER JOIN
(select distinct codigo_asig from curso WHERE periodo = '202020') as cod ON asi.codigo_asig = cod.codigo_asig) as asig
where
asig.codigo_asig
not in (select distinct codigo_asig from curso WHERE periodo = '202110')
-----------------------------------------------------------------------------------------------------------------------------------------------------
/*5h) Construya una funcion que dado un ´ rut_estudiante, periodo, codigo_asignatura,
retorne la nota que el estudiante tuvo en la asignatura. Si el estudiante no tuvo nota, se debe retornar -1. Si el
estudiante no dio la asignatura, se debe retornar ´ 0.*/
CREATE OR REPLACE FUNCTION Retornar_nota(rut_estudiante text, periodo text, codigo_asignatura text)
RETURNS integer LANGUAGE plpgsql
AS $function$
DECLARE
	nota_f integer;
	estudiante_f text;
BEGIN
	SELECT r.estudiante into estudiante_f FROM Rendimiento r where estudiante = rut_estudiante and r.codigo_asig = codigo_asignatura and r.periodo = periodo ;
	if (estudiante_f is null) THEN
		return 0;
	end if;
	SELECT nota into nota_f FROM Rendimiento r where r.estudiante = rut_estudiante and r.codigo_asig = codigo_asignatura and r.periodo = periodo;
	if(nota != -1) THEN
		return nota_f;
	else
		return -1;
	end if;
END;
$function$;
-----------------------------------------------------------------------------------------------------------------------------------------------------
/*5i) Construya una consulta que liste los periodos y la 
cantidad de asignaturas dictadas por cada periodo.*/
select periodo, count(*) as cantidad_asignaturas from
(select distinct periodo,asignatura from Periodo_NRC_asig) as s group by periodo
-----------------------------------------------------------------------------------------------------------------------------------------------------