En la carpeta prueba
Primero ejecutar create.sql
luego en todo.sql ejecutar 5c y 5d
luego ejecutar los insert
con eso ya se verá en funcionamiento la 5c) y las 5d) y podría seguir con las otras.
Lo de la carpeta der y mr imagenes es solo por si no puede verlas bien en el PDF.