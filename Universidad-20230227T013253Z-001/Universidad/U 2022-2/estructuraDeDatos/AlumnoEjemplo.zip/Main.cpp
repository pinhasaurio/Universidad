#include "Alumno.h"
using namespace std;

int main()
{
    cout<<"Ingrese edad de alumno"<<endl;
    int edad;
    cin>>edad;
    cout<<"Ingrese nombre de alumno"<<endl;
    string nombre;
    cin>>nombre;
    Alumno a1(nombre,edad);
    edad = a1.getEdad();
    nombre = a1.getNombre();
    cout<<"La edad del alumno "<<nombre<<" es: "<<edad<<endl;
    return 0;
}