#include<string>
#include<iostream>
#pragma once
using namespace std;
class Alumno
{
    private:
        string nombre;
        int edad;
        Alumno *aptr;
    public:
        Alumno(string _nombre, int _edad);
        int getEdad();
        string getNombre();
        void setEdad(int _edad);
        void setNombre(string _nombre);
};
