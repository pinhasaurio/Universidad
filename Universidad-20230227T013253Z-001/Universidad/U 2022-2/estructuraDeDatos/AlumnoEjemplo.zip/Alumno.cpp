#include"Alumno.h"
using namespace std;
Alumno::Alumno(string _nombre, int _edad)
{
    edad = _edad;
    nombre = _nombre;
};

int Alumno::getEdad()
{
    return edad;
};

string Alumno::getNombre()
{
    return nombre;
};

void Alumno::setEdad(int _edad)
{
    edad = _edad;
};

void Alumno::setNombre(string _nombre)
{
    nombre = _nombre;
};